#!/usr/bin/python

import os
import sys

import urllib2
import json

base_url = "https://graph.facebook.com/v2.5/"
access_token = "&access_token=your access_token"

page_id = "the page id (e.g., United: 199504650087085)"
fields = "?fields=about,likes,name,talking_about_count"

# form a url
url = base_url+page_id+fields+access_token

# send the request
response = urllib2.urlopen(url)

# create a json object based on the response
json_obj = json.load(response)

about = json_obj['about']
like_count = json_obj['likes']
name = json_obj['name']
talking_count = json_obj['talking_about_count']

print 'about :',about
print 'likes:',like_count
print 'name:',name
print 'talking count:',talking_count
