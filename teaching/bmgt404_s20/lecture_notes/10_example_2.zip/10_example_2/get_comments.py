#!/usr/bin/python

import os
import sys

import urllib2
import json

def extract_comments(url):
	# send the request
	response = urllib2.urlopen(url)

	# create a json object based on the response
	json_obj = json.load(response)
	
	comments = []
	if 'comments' not in json_obj:
	    comments = json_obj['data']

	comments = json_obj['comments']['data']
	for comment in comments: # iterate through all posts
		msg = comment['message']
		ctime = comment['created_time']
		cid = comment['id']
		uid = comment['from']['id']
		uname = comment['from']['name']

		print "cid:",cid
		print "message:",msg
		print "created time:",ctime
		print "user id:",uid
		print "user name:",uname
		
	return json_obj

def main():
	base_url = "https://graph.facebook.com/v2.5/"
	access_token = "&access_token=your access_token"

	page_id = "the post id (e.g., one post on United: 199504650087085_1020506827986859)"
	fields = "?fields=comments"

	url = base_url+page_id+fields+access_token
	json_obj = extract_comments(url)

	# if doesn't contain next, terminate
	if 'next' not in json_obj['comments']['paging']:
		print "no next comments"
	else: # get another 25 comments
		next_url = json_obj['comments']['paging']['next']
		extract_comments(next_url)


if __name__ == '__main__':
	main()
