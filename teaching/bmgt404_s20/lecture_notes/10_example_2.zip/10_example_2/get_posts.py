#!/usr/bin/python

import os
import sys

import urllib2
import json


def extract_posts(url):
	# send the request
	response = urllib2.urlopen(url)

	# create a json object based on the response
	json_obj = json.load(response)

        posts = []
        
        if 'posts' in json_obj:
            posts = json_obj['posts']['data'] 
        else:
	   posts = json_obj['data']
	for post in posts: # iterate through all posts
	    msg = ''
	    if 'message' in post:
	        msg = post['message']
	    elif 'story' in post:
	        msg = post['story']
	        
	    ctime = post['created_time']
	    pid = post['id']
	    print "pid:",pid
	    print "message:",msg
	    print "created time:",ctime
		
	return json_obj

def main():
	base_url = "https://graph.facebook.com/v2.5/"
	access_token = "&access_token=your access token"

	page_id = "the page id (e.g., United: 199504650087085)"
	fields = "?fields=posts"

	url = base_url+page_id+fields+access_token
	json_obj = extract_posts(url)
	
	if 'next' not in json_obj['posts']['paging']:
		print "next does not exist"
	else:
		next_url = json_obj['posts']['paging']['next']
		extract_posts(next_url) # get another 25 posts


if __name__ == '__main__':
	main()
