
1. Data structure

There are two files inside the "data_example" folder.

"data_example.txt" is an example of data file. The explanation of the columns is as follows:

'Id' is the post Id;
'PostTypeId' indicates whether the post is a question (PostTypeId is 1) or an answer (PostTypeId is 2);
'ParentId' is the Id of the associated question if the post is an answer;
'Body' is the content of the post;
'CreationDate' is the timestamp;
'Score' is the number of votes the post received ('Score' is not required unless the 'weight_type' is set as 'weight').

"data_example_vocab.txt" is the dictionary built for the "data_example.txt". Its first column is the list of vocabulary, and its second column is the word frequency.

======================================================

2. Code structure

'tmokc_model.py' implements the core of the TM-OKC topic model;
'tmokc_run.py' analyzes the textual data using 'tmokc_model.py'. 

The input of 'tmokc_run.py' is the two files inside the "data_example" folder. Description of the output can be found in the annotations inside 'tmokc_run.py'.


3. How to run the code

Two examples of running the code are as follows.

python3 tmokc_run.py --number_of_topics=10 --weight_type=mean --data_name=data_example

python3 tmokc_run.py --number_of_topics=20 --weight_type=decay --weight_decay=0.8 --data_name=data_example