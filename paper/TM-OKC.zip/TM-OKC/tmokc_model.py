#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging
import copy

logger = logging.getLogger('gensim.models.tmokc_model')


import numpy as np # for arrays, array broadcasting etc.
# np.seterr(divide='ignore') # ignore 0*log(0) errors
from numpy.linalg import pinv, det
from scipy.optimize import minimize

from gensim import interfaces, utils, matutils
from gensim.matutils import dirichlet_expectation

from scipy.special import logsumexp
from scipy.special import gammaln

# for parallel
from joblib import Parallel, delayed, effective_n_jobs
from sklearn.utils import gen_even_slices
import time
import warnings
warnings.filterwarnings("ignore")

EPS = np.finfo(float).eps

class Tmokc_Model(interfaces.TransformationABC):
    """
    The constructor estimated Dynamic Q&A (TM-OKC) Topic Model parameters based on a
    training corpus:

    >>> dqa = Tmokc_Model(corpus_question, corpus_answers, num_topics=10)

    """

    def __init__(self, corpus_question=None, corpus_answers=None, num_topics=10, id2word=None,
            estep_convergence=0.000001, em_convergence=0.00001,
            e_max_iterations=50, em_max_iterations=50,
            minimum_probability=0.0, minimum_phi_value=0.0, gamma=0.0, 
            weight_type = 'mean', weights= None, decay = 0.9, sigma_q = None, sigma_a = None,
            optimization_method = 'L-BFGS-B', n_jobs = 1):
        """
        `num_topics` is the number of requested latent topics to be extracted
        from the training corpus.

        `id2word` is a mapping from word ids (integers) to words (strings).
        It is used to determine the vocabulary size, as well as for debugging
        and topic printing.

        The variational EM runs until the relative change in the likelihood
        bound is less than `em_convergence`.

        In each EM iteration, the E-step runs until the relative change in
        the likelihood bound is less than `estep_convergence`.

        weights: 'mean','decay', or a given list

        """

        # store user-supplied parameters
        self.id2word = id2word
        self.estep_convergence = estep_convergence  # relative change we need to achieve in E-step
        self.em_convergence = em_convergence  # relative change we need to achieve in Expectation-Maximization
        self.em_max_iterations = em_max_iterations
        self.e_max_iterations = e_max_iterations
        self.minimum_probability = minimum_probability
        self.minimum_phi_value = minimum_phi_value
        self.weight_type = weight_type
        self.weights = weights
        self.decay = decay
        self.optimization_method = optimization_method
        self.n_jobs = n_jobs

        if corpus_question is None and self.id2word is None:
            raise ValueError('At least one of corpus/id2word must be specified, to establish input space dimensionality')

        if self.id2word is None:
            logger.warning("No word id mapping provided; initializing from corpus, assuming identity")
            corpus = corpus_question
            for answers in corpus_answers:
                corpus += answers
            self.id2word = utils.dict_from_corpus(corpus)
            self.num_terms = len(self.id2word)
        elif len(self.id2word) > 0:
            self.num_terms = 1 + max(self.id2word.keys())
        else:
            self.num_terms = 0

        if self.num_terms == 0:
            raise ValueError("cannot compute CTL over an empty collection (no terms)")

        self.num_topics = int(num_topics)
        self.num_docs = len(corpus_question)
        self.num_answers = 0
        for answers in corpus_answers:
            self.num_answers += len(answers)     

        # initialize a model with zero-mean, diagonal covariance gaussian and
        # random topics seeded from the corpus
        if sigma_q is None:
            sigma_q = 10/self.num_topics
        if sigma_a is None:
            sigma_a = 1/self.num_topics

        self.mu = np.zeros(self.num_topics)
        
        self.sigma_question = np.eye(self.num_topics) * sigma_q
        self.sigma_question_inverse = pinv(self.sigma_question)
        
        self.sigma_answer_0 = np.eye(self.num_topics) * sigma_a
        self.sigma_answer_0_inverse = pinv(self.sigma_answer_0)

        self.sigma_answer_1 = np.eye(self.num_topics) * sigma_a
        self.sigma_answer_1_inverse = pinv(self.sigma_answer_1)
        
        self.alpha = np.zeros(self.num_terms) + 0.1
        self.delta = np.zeros(2) + 0.1

        # the weight between questions and answers
        self.gamma = gamma

        # initialize the variational topic-word distribution
        self.tau = np.random.gamma(100., 1. / 100., (self.num_topics, self.num_terms))
        
        self.total_em_iterations = 0
        # if a training corpus_question and corpus_answers was provided, 
        # start estimating the model right away
        if corpus_question is not None and corpus_answers is not None:
            self.expectation_maximization(corpus_question, corpus_answers, weights= self.weights)

    def __str__(self):
        return "Tmokc_Model(num_terms=%s, num_topics=%s)" % \
                (self.num_terms, self.num_topics)

    def weight(self, t, weights_d):
        if self.weight_type == 'mean':
            return np.ones(t) * 1/t
        if self.weight_type == 'decay':
            norm = (1-self.decay**t)/(1-self.decay)
            return np.array([self.decay**(t-1-i)/norm for i in range(0,t)])
        if self.weight_type == 'weight':
            return np.array([(weights_d[i]+1)/(sum(weights_d[0:t])+t) \
                                 for i in range(0,t)])

    def expectation_maximization(self, corpus_question, corpus_answers, iterations = None,
                                        weights = None):
        """
        Expectation-Maximization algorithm.
        During E-step, variational parameters are optimized with fixed model parameters.
        During M-step, model parameters are optimized given statistics collected in E-step.
        """
        if iterations is None:
            iterations = self.em_max_iterations

        last_bound = None
        total_number_words = 0
        for question in corpus_question:
            total_number_words += sum([cnt for _, cnt in question])
        for answers in corpus_answers:
            for answer in answers:
                total_number_words += sum([cnt for _, cnt in answer])

        for iteration in range(iterations):
            # E-step and collect sufficient statistics for the M-step
            if self.n_jobs ==1:
                lamda_question, nu2_question, suff_stats_question, \
                lamda_answers, nu2_answers, suff_stats_answers, \
                viu_document, fi_answers, fi_norm \
                = self.do_estep(corpus_question, corpus_answers, weights = weights)
            if self.n_jobs >=2:
                lamda_question, nu2_question, suff_stats_question, \
                lamda_answers, nu2_answers, suff_stats_answers, \
                viu_document, fi_answers, fi_norm \
                = self.do_estep_parallel(corpus_question, corpus_answers, weights = weights,
                    n_jobs = self.n_jobs, verbose =10)

            # check the convergence of likelihodd
            bound = self.corpus_bound(corpus_question, corpus_answers, \
                    lamda_question, nu2_question, lamda_answers, nu2_answers, \
                    viu_document, fi_norm, weights = weights)

            if iteration % 1 == 0:
                print ("Per_word_perplexity after em-iteration %d is %f" %(iteration, np.exp(-bound/total_number_words)))

            if last_bound and abs((bound - last_bound)/last_bound) < self.em_convergence:
                print("EM break in em-step iteration %d" % iteration)
                break
            last_bound = bound

            # M-step
            self.do_mstep(lamda_question, nu2_question, suff_stats_question,
                lamda_answers, nu2_answers, suff_stats_answers, 
                fi_answers, weights = weights)
            self.total_em_iterations += 1

        return self


    def do_mstep(self, lamda_question, nu2_question, suff_stats_question,
                lamda_answers, nu2_answers, suff_stats_answers, 
                fi_answers, weights = None):
        """
        mstep does not need "viu_document"
        Optimize model's parameters using the statictics collected
        during the e-step
        len(lamda_answers) = len(lamda_question), lamda_answers[i].shape = (len(answers), num_topics)
        suff_stats_answers.shape = suff_stats_question.shape = (num_topic, self.num_terms)
        len(fi_answers) = len(lamda_answers), fi_answers[i].shape = (len(answers), 2)
        """
        # update the parameters of topic-term distribution
        self.tau = self.alpha+ suff_stats_question + suff_stats_answers

        # update the parameters of topic distribution
        self.mu = np.mean(lamda_question, axis =0)

        self.sigma_question = np.diag(np.mean(nu2_question, axis=0))
        adjusted_lamda_question = lamda_question - self.mu 
        self.sigma_question += np.dot(adjusted_lamda_question.T, adjusted_lamda_question)/self.num_docs
        self.sigma_question_inverse = pinv(self.sigma_question)

        self.sigma_answer_0 = np.zeros((self.num_topics, self.num_topics))
        for d in range(len(lamda_question)):
            if weights == None:
                weights_d = None
            else:
                weights_d = weights[d]
            self.sigma_answer_0 += np.diag(np.dot(fi_answers[d][:,0],nu2_answers[d]))
            self.sigma_answer_0 += np.diag(nu2_question[d,:] *
             (fi_answers[d][0,0]+fi_answers[d][1:,0].sum()/(1+self.gamma)**2)
             )
            for t in range(1, len(nu2_answers[d])):
                self.sigma_answer_0 += fi_answers[d][t,0] * np.diag(
                    np.dot((self.gamma * self.weight(t, weights_d)/(1+self.gamma))**2, \
                    nu2_answers[d][0:t,:])
                    )                                       

            adjust_lamda_answer = lamda_answers[d][0,:]-lamda_question[d,:]
            self.sigma_answer_0 += fi_answers[d][0,0] * np.outer(adjust_lamda_answer, adjust_lamda_answer)
            for t in range(1, len(nu2_answers[d])):
                adjust_lamda_answer = lamda_answers[d][t,:] - lamda_question[d,:] * 1/(1+self.gamma)
                adjust_lamda_answer -= np.dot(self.gamma * self.weight(t, weights_d)/(1+self.gamma), \
                    lamda_answers[d][0:t,:])
                self.sigma_answer_0 += fi_answers[d][t,0] * np.outer(adjust_lamda_answer, adjust_lamda_answer)
        normalizer_0 = sum([fi[:,0].sum() for fi in fi_answers])
        self.sigma_answer_0 = self.sigma_answer_0/normalizer_0
        self.sigma_answer_0_inverse = pinv(self.sigma_answer_0)

        self.sigma_answer_1 = np.zeros((self.num_topics, self.num_topics))
        for d in range(len(lamda_question)):
            self.sigma_answer_1 += np.diag(np.dot(fi_answers[d][:,1],
                (nu2_answers[d] + nu2_question[d,:]))
            )                                     

            for t in range(0, len(nu2_answers[d])):
                adjust_lamda_answer = lamda_answers[d][t,:] - lamda_question[d,:]
                self.sigma_answer_1 += fi_answers[d][t,1] * np.outer(adjust_lamda_answer, adjust_lamda_answer)
        normalizer_1 = sum([fi[:,1].sum() for fi in fi_answers])
        self.sigma_answer_1 = self.sigma_answer_1/normalizer_1
        self.sigma_answer_1_inverse = pinv(self.sigma_answer_1)

        # update of self.gamma
        A = 0
        for d in range(len(lamda_question)):
            if weights == None:
                weights_d = None
            else:
                weights_d = weights[d]            
            A += fi_answers[d][1:,0].sum() * \
                    np.sum(nu2_question[d,:] * np.diag(self.sigma_answer_0_inverse))
            for t in range(1, len(nu2_answers[d])):
                lamda_adjust_1 = lamda_question[d,:] - lamda_answers[d][t,:]
                lamda_adjust_2 = lamda_question[d,:] -  \
                    np.dot(self.weight(t, weights_d), lamda_answers[d][0:t,:])
                A += fi_answers[d][t,0] * lamda_adjust_1.dot(self.sigma_answer_0_inverse).dot(lamda_adjust_2)
        # assert A>=0
        B = 0
        for d in range(len(lamda_question)):
            if weights == None:
                weights_d = None
            else:
                weights_d = weights[d]
            for t in range(1, len(nu2_answers[d])):
                B += fi_answers[d][t,0] * np.dot(
                    (self.weight(t, weights_d))**2,
                    np.dot(nu2_answers[d][0:t,:], np.diag(self.sigma_answer_0_inverse))
                    )

                lamda_adjust_1 = lamda_answers[d][t,:] -  \
                    np.dot(self.weight(t, weights_d), lamda_answers[d][0:t,:])
                lamda_adjust_2 = lamda_question[d,:] -  \
                    np.dot(self.weight(t, weights_d), lamda_answers[d][0:t,:])
                B += fi_answers[d][t,0] * lamda_adjust_1.dot(self.sigma_answer_0_inverse).dot(lamda_adjust_2)                
        # assert B>=0
        self.gamma = A/B
        # print("Gamma is", self.gamma)


    def do_estep(self, corpus_question, corpus_answers, weights = None):
        # estep of EM algorithm
        # input: corpus_question, corpus_answers;
        # corpus_question are multiple questions, list of list of (int, float)
        # corpus_answers are answers of multiple questions, list of list of list of (int, float)

        # output: lamda_question, nu2_question, suff_stats_question; lamda_answers, nu2_answers, suff_stats_answers.
        # lamda_question.shape = nu2.shape = (len(corpus), self.num_topics) 
        # len(lamda_answers) = len(lamda_question), lamda_answers[i].shape = (len(answers), num_topics)
        # suff_stats_answers.shape = suff_stats_question.shape = (num_topic, self.num_terms)

        # initialize document-level statistics for variational_inference
        lamda_question = np.zeros((len(corpus_question), self.num_topics))
        nu2_question = np.ones((len(corpus_question), self.num_topics))  # nu^2

        lamda_answers = []
        nu2_answers = []
        for d in range(len(corpus_question)):
            lamda_answer = np.zeros((len(corpus_answers[d]), self.num_topics))
            nu2_answer = np.ones((len(corpus_answers[d]), self.num_topics))  # nu^2
            lamda_answers.append(lamda_answer)
            nu2_answers.append(nu2_answer)

        viu_document = np.ones((len(corpus_question), 2)) * 0.1
        fi_answers = []
        for d in range(len(corpus_question)):
            fi_answer = np.ones((len(corpus_answers[d]), 2)) * 0.5
            fi_answers.append(fi_answer)
        fi_norm = []

        # initialize sufficient statistics
        suff_stats_question = np.zeros((self.num_topics, self.num_terms))
        suff_stats_answers = np.zeros((self.num_topics, self.num_terms))

        # calculate the E(log(\beta))
        Elogbeta = dirichlet_expectation(self.tau)

        for d, question in enumerate(corpus_question):
            if weights == None:
                weights_d = None
            else:
                weights_d = weights[d]

            # get the data for questions
            # get the word_ids_question and cnts_question
            word_ids_question = [int(word_id) for word_id, _ in question]
            cnts_question = np.array([cnt for _, cnt in question])
            words_num_question = cnts_question.sum()
            # get the lamda_question_doc and nu2_question_doc
            lamda_question_doc = lamda_question[d,:] # lamda_question_doc.shape=[num_topics,]
            nu2_question_doc = nu2_question[d,:]

            # get the data for answers
            # get the word_ids_answers and cnts_answers
            word_ids_answers = []
            cnts_answers = []
            words_num_answers = []
            for answer in corpus_answers[d]:
                word_ids_answers.append([int(word_id) for word_id, _ in answer])
                cnts_answers.append(np.array([cnt for _, cnt in answer]))
            words_num_answers = [nums.sum() for nums in cnts_answers]
            # get the lamda_answers_doc and nu2_answers_doc
            lamda_answers_doc = lamda_answers[d] # lamda_answers_doc.shape = [len(answers), num_topics]
            nu2_answers_doc = nu2_answers[d]

            # get the data for novelty
            viu_document_doc = viu_document[d,:] # viu_document_doc.shape=[2,]
            fi_answers_doc = fi_answers[d]  # fi_answers_doc.shape=[len(answers),2]

            # start the variational inference
            last_doc_bound = None   # initialize the last_doc_bound as none.

            zeta_question_doc = self.optimize_zeta(lamda_question_doc,  \
                                nu2_question_doc)   # update zeta_doc before iteration
            phi_question_doc = self.optimize_phi(lamda_question_doc,    \
                                Elogbeta[:, word_ids_question]) # update phi_doc before iteration
            zeta_answers_doc = [self.optimize_zeta(lamda_answers_doc[i,:], \
                nu2_answers_doc[i,:])  for  i in range(len(lamda_answers_doc))]
            phi_answers_doc = [self.optimize_phi(lamda_answers_doc[i,:],    \
                Elogbeta[:, word_ids_answers[i]]) for i in range(len(lamda_answers_doc))]

            fi_answers_doc = self.optimize_fi(lamda_question_doc, lamda_answers_doc, \
                                nu2_question_doc, nu2_answers_doc, viu_document_doc, weights_d)

            # iterate between lamda_doc, nu2_doc, phi_doc, 
            # fi_answers_doc, viu_document_doc, and zeta_doc
            for iteration in range(self.e_max_iterations):
                
                ####### for the \lamda and \nu2 of question
                arguments = (nu2_question_doc, phi_question_doc, zeta_question_doc, \
                    words_num_question, cnts_question, \
                    fi_answers_doc, lamda_answers_doc, weights_d)
                lamda_question_doc = self.optimize_lamda_question(lamda_question_doc, arguments,\
                                            method= self.optimization_method)
                zeta_question_doc = self.optimize_zeta(lamda_question_doc, nu2_question_doc)
                fi_answers_doc = self.optimize_fi(lamda_question_doc, lamda_answers_doc, \
                                nu2_question_doc, nu2_answers_doc, viu_document_doc, weights_d)

                arguments = (lamda_question_doc, zeta_question_doc, \
                                words_num_question, fi_answers_doc, len(lamda_answers_doc))
                nu2_question_doc = self.optimize_nu2_question(nu2_question_doc, arguments,\
                                            method= self.optimization_method)
                zeta_question_doc = self.optimize_zeta(lamda_question_doc, nu2_question_doc)
                fi_answers_doc = self.optimize_fi(lamda_question_doc, lamda_answers_doc, \
                                nu2_question_doc, nu2_answers_doc, viu_document_doc, weights_d)

                ####### for the \lamda and \nu2 of answers
                for i in range(len(lamda_answers_doc)):
                    arguments = (lamda_answers_doc, nu2_answers_doc[i,:], phi_answers_doc[i], \
                        zeta_answers_doc[i], words_num_answers[i], \
                        cnts_answers[i], fi_answers_doc, lamda_question_doc, i, weights_d)
                    lamda_answers_doc[i,:] = self.optimize_lamda_answer(lamda_answers_doc[i,:], \
                                        arguments, method= self.optimization_method)
                zeta_answers_doc = [self.optimize_zeta(lamda_answers_doc[i,:], \
                        nu2_answers_doc[i,:])  for  i in range(len(lamda_answers_doc))]
                fi_answers_doc = self.optimize_fi(lamda_question_doc, lamda_answers_doc, \
                                nu2_question_doc, nu2_answers_doc, viu_document_doc, weights_d)

                for i in range(len(nu2_answers_doc)):
                    arguments = (lamda_answers_doc[i,:], zeta_answers_doc[i], \
                        words_num_answers[i], fi_answers_doc, \
                        i, weights_d, len(lamda_answers_doc))
                    nu2_answers_doc[i,:] = self.optimize_nu2_answer(nu2_answers_doc[i,:], \
                                        arguments, method= self.optimization_method)
                zeta_answers_doc = [self.optimize_zeta(lamda_answers_doc[i,:], \
                        nu2_answers_doc[i,:])  for  i in range(len(lamda_answers_doc))]
                fi_answers_doc = self.optimize_fi(lamda_question_doc, lamda_answers_doc, \
                                nu2_question_doc, nu2_answers_doc, viu_document_doc, weights_d)

                # update phi
                phi_question_doc = self.optimize_phi(lamda_question_doc,    \
                                Elogbeta[:, word_ids_question]) # update phi_doc before iteration
                phi_answers_doc = [self.optimize_phi(lamda_answers_doc[i,:],    \
                    Elogbeta[:, word_ids_answers[i]]) for i in range(len(lamda_answers_doc))]
                
                # update viu
                viu_document_doc = self.optimize_viu(fi_answers_doc)                 
                fi_answers_doc, fi_norm_doc = self.optimize_fi(lamda_question_doc, lamda_answers_doc, \
                                nu2_question_doc, nu2_answers_doc, viu_document_doc, \
                                weights_d, return_norm=True)

                doc_bound = self.doc_bound(question, corpus_answers[d], \
                    lamda_question_doc, nu2_question_doc, \
                    lamda_answers_doc, nu2_answers_doc, \
                    viu_document_doc, fi_norm_doc, Elogbeta, weights_d = weights_d)

                if last_doc_bound and abs((doc_bound - last_doc_bound)/last_doc_bound) < self.estep_convergence:
                    # print("Document %d break in e-step iteration %d" %(d, iteration))
                    # print("Document %d last_doc_bound is %f"% (d,last_doc_bound))
                    break
                last_doc_bound = doc_bound

            lamda_question[d,:] = lamda_question_doc
            nu2_question[d,:] = nu2_question_doc 
            lamda_answers[d] = lamda_answers_doc # lamda_answers_doc.shape = [len(answers), num_topics]
            nu2_answers[d] = nu2_answers_doc

            viu_document[d,:] = viu_document_doc # viu_document_doc.shape=[2,]
            fi_answers[d] = fi_answers_doc # fi_answers_doc.shape=[len(answers),2]
            fi_norm.append(fi_norm_doc)

            suff_stats_question[:, word_ids_question] += phi_question_doc * cnts_question
            for i in range(len(word_ids_answers)):
                suff_stats_answers[:, word_ids_answers[i]] += phi_answers_doc[i] * \
                    cnts_answers[i]

            # if (d+1) % 500 == 0:
            #     print('Document %d finished e-step' % (d+1))
        # print('Document %d finished e-step' % (len(corpus_question)))

        return lamda_question, nu2_question, suff_stats_question, \
            lamda_answers, nu2_answers, suff_stats_answers, \
            viu_document, fi_answers, fi_norm

    def do_estep_parallel(self, corpus_question, corpus_answers, weights = None,
                                    n_jobs=1, verbose =0):

        n_jobs = effective_n_jobs(n_jobs)
        parallel = Parallel(n_jobs=n_jobs, verbose=max(0,verbose), max_nbytes=None)

        if weights == None:
            results = parallel(
                        delayed(self.do_estep)(corpus_question[idx_slice],
                                    corpus_answers[idx_slice], None)
                            for idx_slice in gen_even_slices(len(corpus_question), n_jobs))
        else:
            results = parallel(
                        delayed(self.do_estep)(corpus_question[idx_slice],
                                    corpus_answers[idx_slice], weights[idx_slice])
                            for idx_slice in gen_even_slices(len(corpus_question), n_jobs))
        # merge result
        lamda_question_all, nu2_question_all, suff_stats_question_all, \
            lamda_answers_all, nu2_answers_all, suff_stats_answers_all, \
            viu_document_all, fi_answers_all, fi_norm_all = zip(*results)
        
        lamda_question = np.vstack(lamda_question_all)
        nu2_question = np.vstack(nu2_question_all)
        # print("lamda_question.shape is", lamda_question.shape)

        lamda_answers = [] 
        for data in lamda_answers_all:
            lamda_answers += data
        nu2_answers = [] 
        for data in nu2_answers_all:
            nu2_answers += data
        # print("lamda_answers.length is", len(lamda_answers))

        # initialize sufficient statistics
        suff_stats_question = np.zeros((self.num_topics, self.num_terms))
        suff_stats_answers = np.zeros((self.num_topics, self.num_terms))

        for data in suff_stats_question_all:
            suff_stats_question += data
        for data in suff_stats_answers_all:
            suff_stats_answers += data 
        # print("suff_stats_answers.shape is", suff_stats_answers.shape)

        viu_document = np.vstack(viu_document_all)
        fi_answers = []
        for data in fi_answers_all:
            fi_answers += data
        fi_norm = []
        for data in fi_norm_all:
            fi_norm += data

        return lamda_question, nu2_question, suff_stats_question, \
            lamda_answers, nu2_answers, suff_stats_answers, \
            viu_document, fi_answers, fi_norm


    def calculate_perplexity(self, corpus_question, corpus_answers, weights = None, 
                                        doc_topic_dis = False):

        if self.n_jobs ==1:
            lamda_question, nu2_question, _, \
            lamda_answers, nu2_answers, _, \
            viu_document, fi_answers, fi_norm \
            = self.do_estep(corpus_question, corpus_answers, weights = weights)
        if self.n_jobs >=2:
            lamda_question, nu2_question, _, \
            lamda_answers, nu2_answers, _, \
            viu_document, fi_answers, fi_norm \
            = self.do_estep_parallel(corpus_question, corpus_answers, weights = weights, \
                n_jobs = self.n_jobs, verbose =10)

        total_bound = self.corpus_bound(corpus_question, corpus_answers, \
            lamda_question, nu2_question, lamda_answers, nu2_answers, \
            viu_document, fi_norm, weights = weights)

        total_number_words = 0
        for question in corpus_question:
            total_number_words += sum([cnt for _, cnt in question])
        for answers in corpus_answers:
            for answer in answers:
                total_number_words += sum([cnt for _, cnt in answer])

        per_word_bound = total_bound/total_number_words
        per_word_perplexity = np.exp(-per_word_bound)

        if doc_topic_dis == True:
            topic_dist_question = np.exp(lamda_question) / np.sum(np.exp(lamda_question), 1)[:,None]  # normalize distribution

            topic_dist_answers = []
            for d in range(len(lamda_answers)):
                topic_dist_answer = \
                    np.exp(lamda_answers[d]) / np.sum(np.exp(lamda_answers[d]), 1)[:,None]  # normalize distribution
                topic_dist_answers.append(topic_dist_answer)

            document_novel_pro = np.exp(viu_document) / np.sum(np.exp(viu_document), 1)[:,None]  # normalize distribution

            return total_bound, per_word_bound, per_word_perplexity, \
                            topic_dist_question, topic_dist_answers, \
                            document_novel_pro, fi_answers 


        return total_bound, per_word_bound, per_word_perplexity

    def corpus_bound(self, corpus_question, corpus_answers, \
                    lamda_question, nu2_question, lamda_answers, nu2_answers, \
                    viu_document, fi_norm, weights = None):
        """
        Estimate the variational bound of all documents
        input: corpus(Q&A), muliplt documents, iterable of list of (int, float); lamda, nu2. 
        output: corpus_bound considering the beta terms

        """
        ##################
        bound = 0.0
        Elogbeta = dirichlet_expectation(self.tau)

        for d, question in enumerate(corpus_question):
            if weights == None:
                weights_d = None
            else:
                weights_d = weights[d]

            lamda_question_doc = lamda_question[d,:]
            nu2_question_doc = nu2_question[d,:]
            lamda_answers_doc = lamda_answers[d]
            nu2_answers_doc = nu2_answers[d]
            fi_norm_doc = fi_norm[d]

            ################### question part
            # E[log p(\eta | \mu, \Sigma)]
            bound -= 0.5 * np.log(det(self.sigma_question))
            bound -= 0.5 * np.sum(nu2_question_doc * np.diag(self.sigma_question_inverse))
            bound -= 0.5 * (lamda_question_doc - self.mu).dot(  \
                self.sigma_question_inverse).dot(lamda_question_doc - self.mu)

            # \sum_n { E[log p(z_n | \eta)]
            Nq = sum([cnt for _, cnt in question])  # number of words in document
            bound -= Nq * logsumexp(lamda_question_doc + 0.5 * nu2_question_doc)

            # \sum_n terms with \phi_{n, i}
            bound += sum(cnt * logsumexp(lamda_question_doc + Elogbeta[:, int(word_id)]) \
                for word_id, cnt in question)

            # H(q(\eta | \lamda, \nu)
            bound += 0.5 * (np.sum(np.log(nu2_question_doc)) + self.num_topics)  # safe_log

            ################### answers part
            for t in range(len(lamda_answers_doc)):
                if t>0:
                    bound += logsumexp(fi_norm_doc[t]) 
                else:
                    bound -= 0.5 * np.log(det(self.sigma_answer_1))
                    bound -= 0.5 * np.sum(nu2_answers_doc[t,:] * \
                        np.diag(self.sigma_answer_1_inverse))
                    bound -= 0.5 * np.sum(nu2_question_doc * \
                        np.diag(self.sigma_answer_1_inverse))
                    bound -= 0.5 * (lamda_answers_doc[t,:] - lamda_question_doc).dot(  \
                        self.sigma_answer_1_inverse).dot(lamda_answers_doc[t,:] - lamda_question_doc) 

                # \sum_n { E[log p(z_n | \eta)]
                Na = sum([cnt for _, cnt in corpus_answers[d][t]])  # number of words in document
                bound -= Na * logsumexp(lamda_answers_doc[t,:] + 0.5 * nu2_answers_doc[t,:])

                # \sum_n terms with \phi_{n, i}
                bound += sum(cnt * logsumexp(lamda_answers_doc[t,:] + \
                    Elogbeta[:, int(word_id)]) \
                    for word_id, cnt in corpus_answers[d][t])

                # H(q(\eta | \lamda, \nu)
                bound += 0.5 * (np.sum(np.log(nu2_answers_doc[t,:])) + self.num_topics)  # safe_log

            bound += np.sum(gammaln(viu_document[d]) - gammaln(self.delta))
            bound += gammaln(np.sum(self.delta)) - gammaln(np.sum(viu_document[d]))
            Elogx_doc = dirichlet_expectation(viu_document[d])
            bound += np.sum((self.delta - viu_document[d]) * Elogx_doc)

        # E[log p(beta | alpha) - log q (beta | tau)]
        bound += np.sum(gammaln(self.tau) - gammaln(self.alpha))
        bound += np.sum(gammaln(np.sum(self.alpha)) -  \
            gammaln(np.sum(self.tau, 1)))
        bound += np.sum((self.alpha - self.tau) * Elogbeta)

        return bound


    def doc_bound(self, question, answers, lamda_question_doc, nu2_question_doc, 
        lamda_answers_doc, nu2_answers_doc, viu_document_doc, fi_norm_doc, Elogbeta, weights_d = None):
        """
        Estimates the likelihood doc_bound for one Q&A document.
        input: one single Q&A document.
        output: doc_bound without considering the beta terms

        """
        doc_bound = 0.0

        ################### question part
        # E[log p(\eta | \mu, \Sigma)]
        doc_bound -= 0.5 * np.log(det(self.sigma_question))
        doc_bound -= 0.5 * np.sum(nu2_question_doc * np.diag(self.sigma_question_inverse))
        doc_bound -= 0.5 * (lamda_question_doc - self.mu).dot(  \
            self.sigma_question_inverse).dot(lamda_question_doc - self.mu)

        # \sum_n { E[log p(z_n | \eta)]
        Nq = sum([cnt for _, cnt in question])  # number of words in document
        doc_bound -= Nq * logsumexp(lamda_question_doc + 0.5 * nu2_question_doc)

        # \sum_n terms with \phi_{n, i}
        doc_bound += sum(cnt * logsumexp(lamda_question_doc + Elogbeta[:, int(word_id)]) \
            for word_id, cnt in question)

        # H(q(\eta | \lamda, \nu)
        doc_bound += 0.5 * (np.sum(np.log(nu2_question_doc)) + self.num_topics)  # safe_log

        ################### answers part
        for t in range(len(lamda_answers_doc)):
            if t>0:
                doc_bound += logsumexp(fi_norm_doc[t]) 
            else:
                doc_bound -= 0.5 * np.log(det(self.sigma_answer_1))
                doc_bound -= 0.5 * np.sum(nu2_answers_doc[t,:] * \
                    np.diag(self.sigma_answer_1_inverse))
                doc_bound -= 0.5 * np.sum(nu2_question_doc * \
                    np.diag(self.sigma_answer_1_inverse))
                doc_bound -= 0.5 * (lamda_answers_doc[t,:] - lamda_question_doc).dot(  \
                    self.sigma_answer_1_inverse).dot(lamda_answers_doc[t,:] - lamda_question_doc)             

            # \sum_n { E[log p(z_n | \eta)]
            Na = sum([cnt for _, cnt in answers[t]])  # number of words in document
            doc_bound -= Na * logsumexp(lamda_answers_doc[t,:] + 0.5 * nu2_answers_doc[t,:])

            # \sum_n terms with \phi_{n, i}
            doc_bound += sum(cnt * logsumexp(lamda_answers_doc[t,:] + \
                Elogbeta[:, int(word_id)]) \
                for word_id, cnt in answers[t])

            # H(q(\eta | \lamda, \nu)
            doc_bound += 0.5 * (np.sum(np.log(nu2_answers_doc[t,:])) + self.num_topics)  # safe_log

        doc_bound += np.sum(gammaln(viu_document_doc) - gammaln(self.delta))
        doc_bound += gammaln(np.sum(self.delta)) - gammaln(np.sum(viu_document_doc))
        Elogx_doc = dirichlet_expectation(viu_document_doc)
        doc_bound += np.sum((self.delta - viu_document_doc) * Elogx_doc)

        return doc_bound


    def optimize_zeta(self, lamda_doc, nu2_doc):
        return np.sum(np.exp(lamda_doc + 0.5*nu2_doc))

    def optimize_phi(self, lamda_doc, Elogbeta_doc):

        phi_doc = np.exp(lamda_doc[:, np.newaxis] + Elogbeta_doc)
        phi_norm = phi_doc.sum(axis=0)[np.newaxis,:] # alternatively, phi_norm = np.dot(np.exp(lamda_doc), np.exp(Elogbeta_doc))
        phi_doc = phi_doc/phi_norm

        return phi_doc

    def optimize_fi(self, lamda_question_doc, lamda_answers_doc, 
                        nu2_question_doc, nu2_answers_doc, viu_document_doc,
                        weights_d, return_norm=None):
        Elogx_doc = dirichlet_expectation(viu_document_doc) # prior
        likeli_matrix = np.zeros((len(lamda_answers_doc),2)) # likelihood
        for t in range(len(lamda_answers_doc)):
            likeli_0 = -0.5 * np.log(det(self.sigma_answer_0))
            if t==0:
                likeli_0 -= 0.5 * np.sum(nu2_answers_doc[t,:] * \
                    np.diag(self.sigma_answer_0_inverse))
                likeli_0 -= 0.5 * np.sum(nu2_question_doc * \
                    np.diag(self.sigma_answer_0_inverse))
                likeli_0 -= 0.5 * (lamda_answers_doc[t,:] - lamda_question_doc).dot(  \
                    self.sigma_answer_0_inverse).dot(lamda_answers_doc[t,:] - lamda_question_doc)                
            if t>=1:
                likeli_0 -= 0.5 * np.sum(nu2_answers_doc[t,:] * \
                    np.diag(self.sigma_answer_0_inverse))
                likeli_0 -= 0.5 * np.sum(nu2_question_doc * \
                    np.diag(self.sigma_answer_0_inverse))/(1+self.gamma)**2
                likeli_0 -= np.dot(
                    (self.gamma * self.weight(t, weights_d)/(1+self.gamma))**2, \
                    np.dot(nu2_answers_doc[0:t,:], np.diag(self.sigma_answer_0_inverse))
                    )

                adjust_lamda_answer = lamda_answers_doc[t,:] - lamda_question_doc * 1/(1+self.gamma)
                adjust_lamda_answer -= np.dot(self.gamma * self.weight(t, weights_d)/(1+self.gamma), \
                                                lamda_answers_doc[0:t,:])
                likeli_0 -= 0.5 * adjust_lamda_answer.dot(  \
                    self.sigma_answer_0_inverse).dot(adjust_lamda_answer) 

            likeli_1 = -0.5 * np.log(det(self.sigma_answer_1))
            likeli_1 -= 0.5 * np.sum(nu2_answers_doc[t,:] * \
                np.diag(self.sigma_answer_1_inverse))
            likeli_1 -= 0.5 * np.sum(nu2_question_doc * \
                np.diag(self.sigma_answer_1_inverse))
            likeli_1 -= 0.5 * (lamda_answers_doc[t,:] - lamda_question_doc).dot(  \
                self.sigma_answer_1_inverse).dot(lamda_answers_doc[t,:] - lamda_question_doc)

            likeli_matrix[t,:] = [likeli_0, likeli_1]
        
        fi_norm_doc = Elogx_doc[np.newaxis,:] + likeli_matrix
        fi_0 = 1/(1+np.exp(fi_norm_doc[:,1]-fi_norm_doc[:,0]))
        fi_1 = 1 - fi_0
        fi_answers_doc = np.stack((fi_0,fi_1), axis=1)

        # force the first answer to be novel answer, that is, the first row to be (0,1)
        fi_answers_doc[0,:] = [0,1]

        if return_norm == True:
            return fi_answers_doc, fi_norm_doc      

        return fi_answers_doc

    def optimize_viu(self, fi_answers_doc):
        viu_document_doc = self.delta + fi_answers_doc.sum(axis=0)
        return viu_document_doc

    def optimize_lamda_question(self, lamda_question_doc, arguments, method= 'L-BFGS-B'):
        def f_lamda(lamda_question_doc, *args):
            (nu2_question_doc, phi_question_doc, zeta_question_doc,  \
                words_num_question, cnts_question, \
                    fi_answers_doc, lamda_answers_doc, weights_d) = args

            # question part
            doc_bound = -0.5 * (lamda_question_doc -    \
                self.mu).dot(self.sigma_question_inverse).dot(lamda_question_doc - self.mu)
            doc_bound += np.sum(lamda_question_doc *    \
                np.sum(phi_question_doc * cnts_question, axis=1))
            doc_bound -= words_num_question/zeta_question_doc * \
                np.sum(np.exp(lamda_question_doc + 0.5*nu2_question_doc))

            # answers part
            for t in range(len(lamda_answers_doc)):
                # follower part
                if t==0:
                    doc_bound -= fi_answers_doc[t,0] * 0.5 * \
                    (lamda_answers_doc[t,:] - lamda_question_doc \
                        ).dot(self.sigma_answer_0_inverse).dot(
                        lamda_answers_doc[t,:] - lamda_question_doc)
                if t>=1:
                    adjust_lamda_answer = lamda_answers_doc[t,:] - lamda_question_doc * 1/(1+self.gamma)
                    adjust_lamda_answer -= np.dot(self.gamma * self.weight(t, weights_d)/(1+self.gamma), \
                                                lamda_answers_doc[0:t,:])
                    doc_bound -= fi_answers_doc[t,0] * 0.5 * adjust_lamda_answer.dot(  \
                        self.sigma_answer_0_inverse).dot(adjust_lamda_answer)                                          
                # novel part
                doc_bound -= fi_answers_doc[t,1] * 0.5 * \
                    (lamda_answers_doc[t,:] - lamda_question_doc \
                        ).dot(self.sigma_answer_1_inverse).dot(
                        lamda_answers_doc[t,:] - lamda_question_doc)

            return -doc_bound # scalar


        def df_lamda(lamda_question_doc, *args):
            """
            Returns dL/dlamda

            """
            (nu2_question_doc, phi_question_doc, zeta_question_doc,  \
                words_num_question, cnts_question, \
                    fi_answers_doc, lamda_answers_doc, weights_d) = args

            # question part
            result = -np.dot(self.sigma_question_inverse, (lamda_question_doc - self.mu))
            result += np.sum(phi_question_doc * cnts_question, axis=1)
            result -= words_num_question/zeta_question_doc *    \
                    np.exp(lamda_question_doc + 0.5*nu2_question_doc)

            # answers part
            for t in range(len(lamda_answers_doc)):
                # follower part
                if t==0:
                    result += fi_answers_doc[t,0] * np.dot(self.sigma_answer_0_inverse, \
                        lamda_answers_doc[t,:] - lamda_question_doc)
                if t>=1:
                    adjust_lamda_answer = lamda_answers_doc[t,:] - lamda_question_doc * 1/(1+self.gamma)
                    adjust_lamda_answer -= np.dot(self.gamma * self.weight(t, weights_d)/(1+self.gamma), \
                                                lamda_answers_doc[0:t,:])
                    result += fi_answers_doc[t,0] * np.dot(self.sigma_answer_0_inverse, \
                        adjust_lamda_answer) * 1/(1+self.gamma) 
                # novel part                           
                result += fi_answers_doc[t,1] * np.dot(self.sigma_answer_1_inverse, \
                    lamda_answers_doc[t,:] - lamda_question_doc)

            return -result # vector, shape is [k,]

        # maximize f = minimize -f
        optimize_result = minimize(f_lamda, lamda_question_doc, arguments, \
                                    method= method, jac= df_lamda)

        return optimize_result.x



    def optimize_lamda_answer(self, lamda_answer_doc, arguments, method= 'L-BFGS-B'):
        def f_lamda(lamda_answer_doc, *args):
            (lamda_answers_doc, nu2_answer_doc, phi_answer_doc, zeta_answer_doc,     \
                words_num_answer, cnts_answer, fi_answers_doc,  \
                    lamda_question_doc, t, weights_d) = args
            lamda_answers_doc[t,:] = lamda_answer_doc
            
            # follower part
            if t==0:
                doc_bound = -fi_answers_doc[t,0] * 0.5 * (lamda_answers_doc[t,:] - lamda_question_doc \
                        ).dot(self.sigma_answer_0_inverse).dot(
                        lamda_answers_doc[t,:] - lamda_question_doc)
            if t>=1:
                adjust_lamda_answer = lamda_answers_doc[t,:] - lamda_question_doc * 1/(1+self.gamma)
                adjust_lamda_answer -= np.dot(self.gamma * self.weight(t, weights_d)/(1+self.gamma), \
                                            lamda_answers_doc[0:t,:])
                doc_bound = -fi_answers_doc[t,0] * 0.5 * adjust_lamda_answer.dot(  \
                    self.sigma_answer_0_inverse).dot(adjust_lamda_answer)  

            for j in range(t+1, len(lamda_answers_doc)):
                adjust_lamda_answer = lamda_answers_doc[j,:] - lamda_question_doc * 1/(1+self.gamma)
                adjust_lamda_answer -= np.dot(self.gamma * self.weight(j, weights_d)/(1+self.gamma), \
                                            lamda_answers_doc[0:j,:])
                doc_bound -= 0.5 * adjust_lamda_answer.dot(  \
                    self.sigma_answer_0_inverse).dot(adjust_lamda_answer)

            # novel part
            doc_bound -= fi_answers_doc[t,1] * 0.5 * (lamda_answers_doc[t,:] - lamda_question_doc \
                        ).dot(self.sigma_answer_1_inverse).dot(
                        lamda_answers_doc[t,:] - lamda_question_doc)

            # words part
            doc_bound += np.sum(lamda_answer_doc *    \
                np.sum(phi_answer_doc * cnts_answer, axis=1))
            doc_bound -= words_num_answer/zeta_answer_doc * \
                np.sum(np.exp(lamda_answer_doc + 0.5*nu2_answer_doc))

            return -doc_bound # scalar


        def df_lamda(lamda_answer_doc, *args):
            """
            Returns dL/dlamda

            """
            (lamda_answers_doc, nu2_answer_doc, phi_answer_doc, zeta_answer_doc,     \
                words_num_answer, cnts_answer, fi_answers_doc,  \
                    lamda_question_doc, t, weights_d) = args
            lamda_answers_doc[t,:] = lamda_answer_doc

            # follower part
            if t==0:
                result = -fi_answers_doc[t,0] * np.dot(self.sigma_answer_0_inverse,     \
                            lamda_answers_doc[t,:] - lamda_question_doc)
            if t>=1:
                adjust_lamda_answer = lamda_answers_doc[t,:] - lamda_question_doc * 1/(1+self.gamma)
                adjust_lamda_answer -= np.dot(self.gamma * self.weight(t, weights_d)/(1+self.gamma), \
                                            lamda_answers_doc[0:t,:])
                result = -fi_answers_doc[t,0] * np.dot(self.sigma_answer_0_inverse,     \
                            adjust_lamda_answer)  

            for j in range(t+1, len(lamda_answers_doc)):
                adjust_lamda_answer = lamda_answers_doc[j,:] - lamda_question_doc * 1/(1+self.gamma)
                adjust_lamda_answer -= np.dot(self.gamma * self.weight(j, weights_d)/(1+self.gamma), \
                                            lamda_answers_doc[0:j,:])
                result += fi_answers_doc[t,0] * np.dot(self.sigma_answer_0_inverse, \
                            adjust_lamda_answer) * self.gamma * self.weight(j, weights_d)[t]/(1+self.gamma)                                  

            # novel part
            result -= fi_answers_doc[t,1] * np.dot(self.sigma_answer_1_inverse,     \
                        lamda_answers_doc[t,:] - lamda_question_doc)

            # words part
            result += np.sum(phi_answer_doc * cnts_answer, axis=1)
            result -= words_num_answer/zeta_answer_doc *    \
                    np.exp(lamda_answer_doc + 0.5*nu2_answer_doc)

            return -result # vector, shape is [k,]

        # maximize f = minimize -f
        optimize_result = minimize(f_lamda, lamda_answer_doc, arguments, \
                                    method= method, jac= df_lamda)

        return optimize_result.x


    def optimize_nu2_question(self, nu2_question_doc, arguments, method= 'L-BFGS-B'):
        def f_nu2(nu2_question_doc, *args):
            (lamda_question_doc, zeta_question_doc, \
                words_num_question, fi_answers_doc, T) =args

            doc_bound = -0.5 * np.sum(nu2_question_doc * np.diag(self.sigma_question_inverse))
            doc_bound -= words_num_question/zeta_question_doc *    \
                             np.sum(np.exp(lamda_question_doc + 0.5*nu2_question_doc))

            assert T>=1
            # follower part
            doc_bound -= fi_answers_doc[0,0] * 0.5 * np.sum(nu2_question_doc *  \
                            np.diag(self.sigma_answer_0_inverse))
            doc_bound -= fi_answers_doc[1:,0].sum() * 0.5 * np.sum(nu2_question_doc *  \
                            np.diag(self.sigma_answer_0_inverse)) /(1+self.gamma)**2
            # novel part
            doc_bound -= fi_answers_doc[:,1].sum() * 0.5 * np.sum(nu2_question_doc *  \
                            np.diag(self.sigma_answer_1_inverse))

            doc_bound += 0.5 * np.sum(np.log(nu2_question_doc)) # safe divide

            return -doc_bound

        def df_nu2(nu2_question_doc, *args):
            """
            Returns dL/dnu2

            """
            (lamda_question_doc, zeta_question_doc, \
                words_num_question, fi_answers_doc, T) =args

            result = -0.5 * np.diag(self.sigma_question_inverse)
            result -= 0.5 * words_num_question/zeta_question_doc *  \
                            np.exp(lamda_question_doc + 0.5*nu2_question_doc)

            assert T>=1
            # follower part
            result -= 0.5 * fi_answers_doc[0,0] * np.diag(self.sigma_answer_0_inverse)
            result -= 0.5 * fi_answers_doc[1:,0].sum() * \
                    np.diag(self.sigma_answer_0_inverse) /(1+self.gamma)**2
            # novel part
            result -= 0.5 * fi_answers_doc[:,1].sum() * np.diag(self.sigma_answer_1_inverse)            

            result += 0.5 / (nu2_question_doc)  # safe divide

            return -result

        # constraints : we need nu2[i] >= 0
        constraints = [(0, None) for _ in range(self.num_topics)]

        optimize_result = minimize(f_nu2, nu2_question_doc, arguments,  \
                method= method, jac= df_nu2, bounds=constraints)
        
        return optimize_result.x


    def optimize_nu2_answer(self, nu2_answer_doc, arguments, method= 'L-BFGS-B'):
        def f_nu2(nu2_answer_doc, *args):
            (lamda_answer_doc, zeta_answer_doc, words_num_answer, fi_answers_doc, \
                t, weights_d, T) =args

            # follower part
            doc_bound = -fi_answers_doc[t,0] * 0.5 * \
                    np.sum(nu2_answer_doc * np.diag(self.sigma_answer_0_inverse))
            for j in range(t+1, T):
                doc_bound-= fi_answers_doc[t,0] * 0.5 * \
                        np.sum(nu2_answer_doc * np.diag(self.sigma_answer_0_inverse)) *  \
                            (self.gamma * self.weight(j, weights_d)[t]/(1+self.gamma))**2
            # novel part
            doc_bound -= fi_answers_doc[t,1] * 0.5 * \
                    np.sum(nu2_answer_doc * np.diag(self.sigma_answer_1_inverse))

            # words part
            doc_bound -= words_num_answer/zeta_answer_doc *    \
                             np.sum(np.exp(lamda_answer_doc + 0.5*nu2_answer_doc))
            doc_bound += 0.5 * np.sum(np.log(nu2_answer_doc)) # safe divide

            return -doc_bound

        def df_nu2(nu2_answer_doc, *args):
            """
            Returns dL/dnu2

            """
            (lamda_answer_doc, zeta_answer_doc, words_num_answer, fi_answers_doc, \
                t, weights_d, T) =args

            # follower part            
            result = -fi_answers_doc[t,0] * 0.5 * np.diag(self.sigma_answer_0_inverse)
            for j in range(t+1, T):
                result-= fi_answers_doc[t,0] * 0.5 * np.diag(self.sigma_answer_0_inverse) *  \
                            (self.gamma * self.weight(j, weights_d)[t]/(1+self.gamma))**2
            # novel part            
            result -= fi_answers_doc[t,1] * 0.5 * np.diag(self.sigma_answer_1_inverse)

            # words part
            result -= 0.5 * words_num_answer/zeta_answer_doc *  \
                            np.exp(lamda_answer_doc + 0.5*nu2_answer_doc)

            result += 0.5 / (nu2_answer_doc)  # safe divide

            return -result

        # constraints : we need nu2[i] >= 0
        constraints = [(0, None) for _ in range(self.num_topics)]

        optimize_result = minimize(f_nu2, nu2_answer_doc, arguments,  \
                method=method, jac= df_nu2, bounds=constraints)
        
        return optimize_result.x


    def get_document_topics(self, question, answers, weights_d=None, minimum_probability=None, minimum_phi_value=None,
                            per_word_topics=False):
        """Get the topic distribution for the given document.

        Parameters
        ----------
        question : a single question : list of (int, float)
            The document in BOW format.
        answers : the corresponding answers of the question: list of list of (int, float)
        minimum_probability : float
            Topics with an assigned probability lower than this threshold will be discarded.
        minimum_phi_value : float
            If `per_word_topics` is True, this represents a lower bound on the term probabilities that are included.
             If set to None, a value of 1e-8 is used to prevent 0s.
        per_word_topics : bool
            If True, this function will also return two extra lists as explained in the "Returns" section.

        Returns
        -------
        List of (int, float)
            Topic distribution for the question.
        List of list of (int, float)
            Topic distribution for the answers.
        Array of 2-dimenstion: document-level novelty
        Array of len(answers)*2: answer-level novelty

        """
        if minimum_probability is None:
            minimum_probability = self.minimum_probability

        if minimum_phi_value is None:
            minimum_phi_value = self.minimum_phi_value

        if weights_d == None:
            lamda_question, nu2_question, phis_question, \
            lamda_answers, nu2_answers, phis_answers, \
            viu_document, fi_answers, fi_norm = self.do_estep([question], [answers], None)
        else:
            lamda_question, nu2_question, phis_question, \
            lamda_answers, nu2_answers, phis_answers, \
            viu_document, fi_answers, fi_norm = self.do_estep([question], [answers], [weights_d])            

        topic_dist_question = np.exp(lamda_question[0]) / np.sum(np.exp(lamda_question[0]))  # normalize distribution
        document_topics_question = [
            (topicid, topicvalue) for topicid, topicvalue in enumerate(topic_dist_question)
            if topicvalue >= minimum_probability]

        document_topics_answers = []
        for answer_id in range(len(answers)):
            topic_dist_answer = \
                np.exp(lamda_answers[0][answer_id]) / np.sum(np.exp(lamda_answers[0][answer_id]))  # normalize distribution
            document_topics_answer = [
                (topicid, topicvalue) for topicid, topicvalue in enumerate(topic_dist_answer)
            if topicvalue >= minimum_probability]
            document_topics_answers.append(document_topics_answer)

        document_novel_pro = np.exp(viu_document[0])/np.sum(np.exp(viu_document[0])) # normalize distribution

        if not per_word_topics:
            return document_topics_question, document_topics_answers, \
                        document_novel_pro, fi_answers[0]

    def get_corpus_topics(self, corpus_question, corpus_answers, weights = None):
        """Get the topic distribution for the given document.

        Parameters
        ----------
        corpus_question : a list of questions
            The document in BOW format.
        corpus_answers: a list of the the corresponding answers
        Returns
        -------
        Topic distribution for the questions (np.array) and answers (list of np.array).
        Novelty of Q&A threads and each answer.

        """

        if self.n_jobs ==1:
            lamda_question, nu2_question, _, \
                lamda_answers, nu2_answers, _, \
                viu_document, fi_answers, fi_norm \
                = self.do_estep(corpus_question, corpus_answers, weights = weights)
        if self.n_jobs >=2:
            lamda_question, nu2_question, _, \
                lamda_answers, nu2_answers, _, \
                viu_document, fi_answers, fi_norm \
                = self.do_estep_parallel(corpus_question, corpus_answers, weights = weights,
                    n_jobs = self.n_jobs, verbose =10)

        topic_dist_question = np.exp(lamda_question) / np.sum(np.exp(lamda_question), 1)[:,None]  # normalize distribution

        topic_dist_answers = []
        for d in range(len(lamda_answers)):
            topic_dist_answer = \
                np.exp(lamda_answers[d]) / np.sum(np.exp(lamda_answers[d]), 1)[:,None]  # normalize distribution
            topic_dist_answers.append(topic_dist_answer)

        document_novel_pro = np.exp(viu_document)/np.sum(np.exp(viu_document), 1)[:, None]  # normalize distribution

        return topic_dist_question, topic_dist_answers, document_novel_pro, fi_answers


    def get_topics(self):
        """Get the term-topic matrix learned during inference.
        Returns
        -------
        numpy.ndarray
            The probability for each word in each topic, shape (`num_topics`, `vocabulary_size`).
        """
        topics = self.tau
        return topics / topics.sum(axis=1)[:, None]

    def get_topic_terms(self, topicid, topn=10):
        """
        topicid : int
            The ID of the topic to be returned
        topn : int, optional
            Number of the most significant words that are associated with the topic.
        Returns
        -------
        list of (int, float)
            Word ID - probability pairs for the most relevant words generated by the topic.

        """
        topic = self.get_topics()[topicid]
        topic = topic / topic.sum()  # normalize to probability distribution
        bestn = matutils.argsort(topic, topn, reverse=True)
        return [(idx, topic[idx]) for idx in bestn]

    def show_topic(self, topicid, topn=10):
        """
        topicid : int
            The ID of the topic to be returned
        topn : int, optional
            Number of the most significant words that are associated with the topic.

        Returns
        -------
        list of (str, float)
            Word - probability pairs for the most relevant words generated by the topic.

        """
        return [(self.id2word[id], value) for id, value in self.get_topic_terms(topicid, topn)]