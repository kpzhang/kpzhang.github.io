#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
import nltk
# nltk.download('stopwords')
# nltk.download('punkt')
# nltk.download('wordnet')
# nltk.download('omw-1.4')
from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer
import re
import copy
import pickle

import gensim
from gensim import corpora
from gensim.models import CoherenceModel
import argparse
import os

from tmokc_model import Tmokc_Model

def parse_args():
    parser = argparse.ArgumentParser()
    # parameter set 1
    parser.add_argument('--number_of_topics', dest='number_of_topics', type=int,
                        default=10, help='The number_of_topics')
    parser.add_argument('--e_iterations', type = int,
                        default= 80, help='Maximum number of e_iterations')
    parser.add_argument('--em_iterations', type = int,
                        default= 6, help='Maximum number of em_iterations')
    parser.add_argument('--gamma', type = float,
                        default= 1, help='Initial value of gamma')
    parser.add_argument('--weight_type', type = str,
                        default= "mean") # 'mean', 'decay', 'weight'
    parser.add_argument('--weight_decay', type = float,
                        default= 0.8, help='Value of weight decay')
    parser.add_argument('--n_jobs', type=int,
                        default=8)  
    # parameter set 2
    parser.add_argument('--sigma_q', type = float,
                        default= 1.0, help='Initial value of question topic variance')
    parser.add_argument('--sigma_a', type = float,
                        default= 0.01, help='Initial value of answer topic variance')
    
    # parameter set 3
    parser.add_argument('--optimization_method', type=str,
                        default='L-BFGS-B') # 'L-BFGS-B' or 'CG'
    parser.add_argument('--data_name', type=str,
                        default='data_example')
    return parser.parse_args()

# preprocess textual data
def clean(doc, vocab):
    stop = set(stopwords.words('english'))
    filters = u'[^a-zA-Z]+'
    lemma = WordNetLemmatizer()
    s = nltk.stem.SnowballStemmer('english')  # choose the language used
    url_re = '(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})'
    url_free = re.sub(url_re, ' ', doc)    
    punc_free = re.sub(filters, ' ', url_free)
    stop_free = " ".join([i for i in punc_free.lower().split() if (i not in stop and len(i)>=3)])
    normalized = [s.stem(lemma.lemmatize(word)) for word in nltk.word_tokenize(stop_free)\
                  if s.stem(lemma.lemmatize(word)) in vocab]
    return normalized

def main():            
    args = parse_args()
    # parameter set 1
    number_of_topics = args.number_of_topics;
    e_iterations = args.e_iterations;
    em_iterations = args.em_iterations;
    gamma = args.gamma;
    weight_type = args.weight_type;
    weight_decay = args.weight_decay;
    n_jobs = args.n_jobs;
    
    # parameter set 2
    sigma_q = args.sigma_q; 
    sigma_a = args.sigma_a;
    
    # parameter set 3
    optimization_method = args.optimization_method;
    data_name = args.data_name
    data_path = data_name+"/"
    output_name = args.data_name + "_topics_"+ str(args.number_of_topics)

    if not os.path.exists('results/'):
        os.makedirs('results/')

    print("Start tm_okc with %d topics" % number_of_topics)
    print("The arguments are", args)
    
    ############################################################################
    ############################################################################
    vocab = pd.read_csv(data_path +data_name+"_vocab.txt",sep='\t',header=None)
    vocab = vocab.iloc[:,0].map(str).values.tolist()
    
    data_raw = pd.read_csv(data_path + data_name+ ".txt",sep="\t", encoding='utf-8')
    data_raw.sort_values(by=['CreationDate'],inplace=True)
    
    ########## First, build and output the dictionary
    dictionary = corpora.Dictionary([vocab])

    ########## Second, prepare corpus_question and corpus_answers
    # prepare docs
    docs_question = data_raw[data_raw['PostTypeId']==1]["Body"].values.tolist() # convert to list
    docs_question_id = data_raw[data_raw['PostTypeId']==1]["Id"].values.tolist() # convert to list    
    
    docs_answers = [];
    docs_answers_id = [];
    if weight_type == 'weight':
        docs_answers_score = [];

    for question_id in docs_question_id:
        answers = data_raw.loc[data_raw['ParentId']== question_id,"Body"].values.tolist()
        docs_answers.append(answers)
        ids = data_raw.loc[data_raw['ParentId']== question_id,'Id'].values.tolist()
        docs_answers_id.append(ids)
        if weight_type == 'weight':
            scores = data_raw.loc[data_raw['ParentId']== question_id,'Score'].abs().values.tolist()
            docs_answers_score.append(scores)
    
    data = []
    # build corpus 
    corpus_question = []
    for d, question in enumerate(docs_question):
        question_clean = clean(question, vocab)
        doc = dictionary.doc2bow(question_clean)
        corpus_question.append(doc)
        data.append(question_clean)
    corpus_answers = []
    for d, answers in enumerate(docs_answers):
        docs = []
        for answer in answers:
            answer_clean = clean(answer, vocab)
            doc = dictionary.doc2bow(answer_clean)
            docs.append(doc)
            data.append(answer_clean)
        corpus_answers.append(docs)
    
    corpus = copy.deepcopy(corpus_question)
    for corpus_answer in corpus_answers:
        for answer in corpus_answer:
            corpus.append(answer)
        
    ##################################################
    ##################################################        
    if weight_type == 'weight':
        weights = docs_answers_score
    else:
        weights = None

    print('Total number of questions is', len(corpus_question))
    answer_num = 0
    for answers in corpus_answers:
        answer_num += len(answers)
    print('Total number of answers is', answer_num)

    #############################################################
    #############################################################
    ####################### Learning process        
    dqa = Tmokc_Model(corpus_question, corpus_answers, \
                   num_topics=number_of_topics, id2word=dictionary, \
                   e_max_iterations= e_iterations, em_max_iterations= em_iterations, \
                   gamma = gamma, weight_type = weight_type, weights = weights, \
                   decay = weight_decay, sigma_q = sigma_q, sigma_a = sigma_a, \
                   optimization_method = optimization_method, n_jobs = n_jobs) 
    with open('results/tmokc_'+output_name, 'wb') as dqa_file:
        pickle.dump(dqa, dqa_file)   
    
    # calculate the perplexity
    (total_bound, per_word_bound, per_word_perplexity, \
        topic_dist_question, topic_dist_answers, document_novel_pro, fi_answers) = \
        dqa.calculate_perplexity(corpus_question, corpus_answers, weights, True)
    print ("Per_word_perplexity is %f" % per_word_perplexity)
    
    ############################################################
    ############################################################
    # calculate the coherence score
    topic_terms = []
    for topicid in range(number_of_topics):
        topic_term_value = dqa.show_topic(topicid, topn=10)
        topic_term = [term for term, value in topic_term_value]
        topic_terms.append(topic_term)
    
    #__spec__ = "ModuleSpec(name='builtins', loader=<class '_frozen_importlib.BuiltinImporter'>)"
    cm = CoherenceModel(topics=topic_terms, texts= data, corpus=corpus, \
                        dictionary=dictionary, coherence='c_v')
    coherence = cm.get_coherence()
    print("The c_v conherence score of the model is", coherence)

    ############################################
    ####### output results: the topic-term distribution, document-topic distribution, document novelty etc  
    
    # 1. output topic_terms_dist and topic_top_terms
    terms =  list(dqa.id2word.token2id.keys())
    topic_term_dist = dqa.get_topics().transpose()
    col_names = ["Topic"+str(i) for i in range(1, number_of_topics+1)]
    topic_term_dist = pd.DataFrame(topic_term_dist, index=terms, columns = col_names)
    topic_term_dist.to_csv('results/topic_term_dist_'+output_name+'.csv', index = True)
    
    with open('results/Top20_terms_'+output_name+'.txt','w') as topic_terms:
        for topicid in range(number_of_topics):
            topic_terms.write('The top 20 terms of topic %d are:\n\n' % topicid)
            topic_term_value = dqa.show_topic(topicid, topn=20)
            for term, value in topic_term_value:
                topic_terms.write(term)
                topic_terms.write('\t')
                topic_terms.write(str(value))
                topic_terms.write('\n')
            topic_terms.write('#########################################\n')
        
    # 2. output document_topics_distribution
    question_id = np.array(docs_question_id)
    answers_id = []
    for doc_answers_id in docs_answers_id:
        for doc_answer_id in doc_answers_id:
            answers_id.append(doc_answer_id)
    answers_id = np.array(answers_id)

    topic_dist_answer = np.vstack(topic_dist_answers)
    fi_answer = np.vstack(fi_answers)
    
    question_topics_out = np.concatenate((question_id[:,None], topic_dist_question), 1)
    answers_topics_out = np.concatenate((answers_id[:,None], topic_dist_answer), 1)
    col_names = ["Id"]+["Topic"+str(i) for i in range(1, number_of_topics+1)]    
    pd.DataFrame(question_topics_out,columns=col_names).to_csv(
            'results/topic_dist_question_'+output_name+'.csv', index=False)
    pd.DataFrame(answers_topics_out,columns=col_names).to_csv(
            'results/topic_dist_answer_'+output_name+'.csv', index=False)

    # 3. output the inferred proportion of novel answers in each Q&A thread, and the inferred probability of being novel for each answer
    document_novel_pro_out = np.concatenate((question_id[:,None], document_novel_pro), 1) 
    fi_answers_out = np.concatenate((answers_id[:,None], fi_answer), 1)
    pd.DataFrame(document_novel_pro_out,columns=['Id','follow','novel']).to_csv(
            'results/document_novel_pro_'+output_name+'.csv', index=False)    
    pd.DataFrame(fi_answers_out,columns=['Id','follow_probability','novel_probability']).to_csv(
            'results/fi_answer_'+output_name+'.csv', index=False) 
    
    # 4. output \gamma, reflecting differential impacts of questions and prior answers on the current answer
    print("#########################################")
    print("gamma is", dqa.gamma)
    print("#########################################")

    # 5. output \sigma, reflecting different topic variances between Q&A
    # the normalized trace is the sum of eigenvalue divided by the number of topics, indicating the average variance of each topic
    print("The normalized trace of sigma_question is", np.sum(np.diag(dqa.sigma_question))/number_of_topics)
    pd.DataFrame(dqa.sigma_question).to_csv('results/sigma_question_'+output_name+'.csv', index=False)
    print("#########################################")
    print("The normalized trace of sigma_answer_0 (for follow-up answers) is", np.sum(np.diag(dqa.sigma_answer_0))/number_of_topics)
    print("The normalized trace of sigma_answer_1 (for novel answers) is", np.sum(np.diag(dqa.sigma_answer_1))/number_of_topics)
    pd.DataFrame(dqa.sigma_answer_0).to_csv('results/sigma_answer_0_'+output_name+'.csv', index=False)
    pd.DataFrame(dqa.sigma_answer_1).to_csv('results/sigma_answer_1_'+output_name+'.csv', index=False)


if __name__ == "__main__":
    main()